package org.example.testCases;

import org.example.pages.AmazonLoginPage;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class AmazonLoginTest extends TestBase{
    @Test
    public void init() throws Exception{
        AmazonLoginPage loginPage = PageFactory.initElements(driver, AmazonLoginPage.class);
        loginPage.clickOnSignInButton();
        loginPage.setEmailBox("hksharma73264@gmail.com");
        loginPage.clickOnContinueButton();
        loginPage.setPasswordBox("Kirtihk@98");
        loginPage.clickOnLogInButton();
    }
}
