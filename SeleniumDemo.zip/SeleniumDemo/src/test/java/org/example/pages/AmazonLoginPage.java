package org.example.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class AmazonLoginPage {
    WebDriver driver;
    public AmazonLoginPage(WebDriver driver){
        this.driver = driver;
    }

    @FindBy(how = How.LINK_TEXT, using = "Sign in")
    WebElement signInButton;

    @FindBy(how = How.XPATH, using = "//*[@id='ap_email']")
    WebElement emailBox;

    @FindBy(how = How.XPATH, using = "//*[@id='continue']")
    WebElement continueButton;

    @FindBy(how = How.XPATH, using = "//*[@id='ap_password']")
    WebElement passwordBox;

    @FindBy(how = How.XPATH, using="//*[@id='signInSubmit']")
    WebElement loginButton;

    public void clickOnSignInButton(){
        signInButton.click();
    }

    public void setEmailBox(String email){
        emailBox.sendKeys(email);
    }
    public void setPasswordBox(String pass){
       passwordBox.sendKeys(pass);
    }

    public void clickOnContinueButton(){
        continueButton.click();
    }
    public void clickOnLogInButton(){
        loginButton.click();
    }
}
